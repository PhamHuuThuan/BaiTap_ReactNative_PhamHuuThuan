import React, {useState, useEffect} from 'react';
import { Text, SafeAreaView, StyleSheet, Image, View, TextInput, Pressable } from 'react-native';

export default function App({navigation}) {
  const [name, setName] = useState("");

  return (
    <SafeAreaView style={styles.container}>
      <View style={{felx: 1, alignItems: 'center', justifyContent: 'center'}}>
        <Image source={{uri: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/f1b722df6071a659415a6a4ca4579e9d'}} style={{width: 300, height: 300}}/>
      </View>
      <View style={{felx: 1, alignItems: 'center', justifyContent: 'center'}}>
        <Text style={{fontSize: 25, fontWeight: 'bold', color: '#f0f'}}>MANAGE YOUR</Text>
        <Text style={{fontSize: 25, fontWeight: 'bold', color: '#f0f'}}>TASK</Text>
      </View>
      <View style={{felx: 1, alignItems: 'center', flexDirection: 'row', width: '90%', height: 50, borderColor: 'gray', borderWidth: 1, borderRadius: 10, paddingLeft: 20}}>
        <Image source={{uri: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/ae4449af071ed10e8a3a36a4f72ad1da'}} style={{width: 30, height: 30}}/>
        <TextInput style={{width: '90%', height: 50, paddingLeft: 20, fontSize: 20}}
        placeholder="Enter your name"
        value={name}
        onChangeText={setName}>
        
        </TextInput>
      </View>
      <View style={{felx: 1, alignItems: 'center'}}>
        <Pressable style={{width: 300, height: 50, backgroundColor: 'blue', justifyContent: 'center', alignItems: 'center', borderRadius: 10}}
        onPress={()=>navigation.navigate("Screen02", {name})}>
          <Text style={{fontSize: 20, color: '#fff'}}>GET STARTED -></Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-evenly',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 8,
  }
});
