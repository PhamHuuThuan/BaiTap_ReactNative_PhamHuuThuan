import React, {useState, useEffect} from 'react';
import { Text, SafeAreaView, StyleSheet, Image, View, TextInput, Pressable, FlatList} from 'react-native';

export default function App({route, navigation}) {
  const {isAdd, item, name} = route.params;
  const [workname, setWorkname] = useState(isAdd?"":item.workname);

  const addWork = ()=>{
    var newitem = {"workname": workname};
    fetch('https://67023f17bd7c8c1ccd3e4dff.mockapi.io/huuthuan/WorkList',{
      method: "POST",
      data: newitem,
      headers:{
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(newitem)})
      .then(res=>
      res.json())
      .then(res=>{
        setWorkname("");
        navigation.navigate("Screen02", { name });
    })
  }
  
  const updateWork = ()=>{
    if(workname!==""){
      var newitem = {
        "workname": workname};
      fetch(`https://67023f17bd7c8c1ccd3e4dff.mockapi.io/huuthuan/WorkList/${item.id}`,{
        method: "PUT",
        data: newitem,
        headers:{
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(newitem)})
        .then(res=>
        res.json())
        .then(res=>{
          setWorkname("");
          navigation.navigate("Screen02", { name });
      })
    }
  }
  return (
    <SafeAreaView style={styles.container}>
      <View style={{flexDirection: 'row', width: '90%', justifyContent: 'space-between', marginTop: 20}}>
        <View style={{flexDirection: 'row'}}>
          <Image source={{uri: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/1e56b0d9da173efc560ae741f025d2f1'}}style={{width: 50, height: 50}}/>
          <View style={{justifyContent: 'center', marginLeft: 20}}>
            <Text style={{fontSize: 20, fontWeight: 'bold'}}>Hi ...</Text>
            <Text style={{fontWeight: 'bold', color: 'gray'}}>Have a great day a head</Text>
          </View>
        </View>
        <Pressable
        onPress={()=>{navigation.goBack();}}>
          <Image source={{uri: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/cfb5b067658032fd1870f734369d041b'}}style={{width: 36, height: 36}}/>
        </Pressable>
      </View>
      <View style={{marginTop: 50}}>
         <Text style={{fontSize: 40, fontWeight: 'bold'}}>{isAdd?"ADD YOUR JOB":"EDIT YOUR JOB"}</Text>
      </View>
      <View style={{width: '90%', height: 50, borderWidth: 1, borderRadius: 5, paddingLeft: 10, flexDirection: 'row', alignItems:'center' , marginTop: 50}}>
        <Pressable>
          <Image source={{uri: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/a787bf48e6cd79092fb473ce0163a20f'}}style={{width: 24, height: 30}}/>
        </Pressable>
        <TextInput style={{width: '90%', height: 50, fontSize: 20, marginLeft: 10, paddingLeft: 10, color: 'gray'}}
        placeholder="input your job"
        value={workname}
        onChangeText={setWorkname}/>
      </View>
      <View style={{alignItems: 'center'}}>
        <Pressable style={{width: 300, height: 50, backgroundColor: 'blue', justifyContent: 'center', alignItems: 'center', borderRadius: 10, marginTop: 50}}
        onPress={()=>{isAdd?addWork():updateWork()}}>
          <Text style={{fontSize: 20, color: '#fff'}}>FINISH -></Text>
        </Pressable>
      </View>
      <View style={{felx: 1, alignItems: 'center', justifyContent: 'center', marginTop: 100}}>
        <Image source={{uri: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/f1b722df6071a659415a6a4ca4579e9d'}} style={{width: 300, height: 300}}/>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 8,
  }
});
